<?php

    echo $before_widget;
    echo $before_title . $title . $after_title;
?>

<ul class="pgnyt-articles">

<?php
    $total_articles = count($pgnyt_results->{'response'}->{'docs'});
    for( $i = $total_articles - 1; $i <= $total_articles - $num_articles; $i-- ):
?>
    <li>
        <ul>
            <li>
                <img width="120px" src="<?php echo 'https://www.nytimes.com/' . $pgnyt_results->{'response'}->{'docs'}[$i]->{'multimedia'}[1]->{'url'} ?>" alt="">
            </li>
            <li class="pgnyt-articles-name">
                <a href="#"><?php echo $pgnyt_results->{'response'}->{'docs'}[$i]->{'headline'}->{'main'}; ?></a>
            </li>
            <li class="pgnyt-articles-name">
                <p><?php echo $pgnyt_results->{'response'}->{'docs'}[$i]->{'lead_paragraph'}; ?></p>
            </li>
        </ul>
    </li>
<?php endfor; ?>
</ul>

<?php
    echo $after_widget;
?>