<!-- WP_Widget::get_field_name( string $field_name )
This function should be used in form() methods to create name attributes for fields to be saved by update() -->

<p>
    <label>Title</label>
    <input type="text" class="widget" name="<?php echo $this->get_field_name('title') ?>" value="<?php echo $title; ?>">
</p>

<p>
    <label>How many articles would you like to display</label>
    <input type="text" size="4" name="<?php echo $this->get_field_name('num_articles'); ?>" value="<?php echo $num_articles ?>">
</p>

<p>
    <label>Display image</label>
    <input type="checkbox" name="<?php echo $this->get_field_name('display_image') ?>" value="1" <?php echo checked($display_image, 1) ?> />
</p>